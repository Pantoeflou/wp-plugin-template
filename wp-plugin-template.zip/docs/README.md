# WP Forever - WordPress Plugin Template

A well-documented, opinionated WordPress plugin template that eliminates repetitive boilerplate while teaching best practices.

## Introduction

WP Forever is a **plugin template**, not a framework. It provides a clean starting point with:

- **Clear structure** — Opinionated directory layout that's easy to navigate
- **Comment-heavy code** — Explains the "why", not just the "what"
- **Security baseline** — Nonces, capability checks, sanitization baked in
- **WordPress-native patterns** — Uses core APIs, not custom abstractions

Copy this template, rename it, and start building your plugin immediately.

## Requirements

| Requirement | Version |
|-------------|---------|
| PHP | 8.0+ |
| WordPress | 6.0+ |
| MySQL | 5.7+ or MariaDB 10.3+ |

**No external dependencies required.** Works on standard shared hosting.

## Quick Start

1. **Copy the template**
   ```bash
   cp -r wp-forever my-plugin
   cd my-plugin
   ```

2. **Rename everything** (see [CHECKLIST.md](CHECKLIST.md) for detailed steps)
   - Rename `wp-forever.php` → `my-plugin.php`
   - Find/replace `wp-forever` → `my-plugin` (text domain)
   - Find/replace `WP_FOREVER_` → `MY_PLUGIN_` (constants)
   - Find/replace `wp_forever_` → `my_plugin_` (functions)
   - Find/replace `WP_Forever_` → `My_Plugin_` (classes)

3. **Update plugin header** in `my-plugin.php`
   ```php
   Plugin Name: My Plugin
   Description: What your plugin does.
   Author: Your Name
   ```

4. **Test activation**
   - Copy to `wp-content/plugins/`
   - Activate via WordPress admin
   - Check for errors

5. **Start building!**

## Directory Structure

```
wp-forever/
├── wp-forever.php      # Main plugin file (entry point)
├── uninstall.php       # Cleanup on plugin deletion
├── core/               # Plugin orchestration classes
├── admin/              # Admin-specific code
├── public/             # Front-end code
├── includes/           # Shared utilities
├── templates/          # Theme-overridable templates
├── assets/             # CSS, JS, images
├── languages/          # Translation files
└── docs/               # Documentation
```

See [ARCHITECTURE.md](ARCHITECTURE.md) for detailed explanation of each directory.

## Customization

### Adding Admin Pages

Admin menus and settings pages go in `admin/class-admin.php`:

```php
// In WP_Forever_Admin class:
public function add_menu_pages(): void {
    add_menu_page(
        __( 'My Plugin', 'wp-forever' ),
        __( 'My Plugin', 'wp-forever' ),
        'manage_options',
        'my-plugin',
        array( $this, 'render_admin_page' )
    );
}
```

### Adding Shortcodes

Shortcodes go in `public/class-public.php`:

```php
// In WP_Forever_Public class:
public function register_shortcodes(): void {
    add_shortcode( 'my_shortcode', array( $this, 'render_shortcode' ) );
}
```

### Adding AJAX Handlers

AJAX handlers go in the appropriate class (admin or public):

```php
// Register the handler:
add_action( 'wp_ajax_my_action', array( $this, 'handle_ajax' ) );

// The handler method:
public function handle_ajax(): void {
    check_ajax_referer( 'wp_forever_ajax', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Permission denied' );
    }

    // Process request...

    wp_send_json_success( array( 'message' => 'Done' ) );
}
```

## Security

This template includes security patterns throughout. Key principles:

1. **Always verify nonces** for form submissions and AJAX
2. **Always check capabilities** before privileged actions
3. **Always sanitize input** before processing
4. **Always escape output** before displaying

See code comments for specific examples of each pattern.

## Contributing

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Make your changes with clear commit messages
4. Submit a pull request

## License

GPL-2.0-or-later — See [LICENSE](../LICENSE) for details.

This license is compatible with WordPress.org plugin directory requirements.

---

**Need help?** Check the detailed [ARCHITECTURE.md](ARCHITECTURE.md) or [CHECKLIST.md](CHECKLIST.md).
