<?php
/**
 * Public-facing functionality.
 *
 * This class handles everything that runs on the front-end (public) side:
 * - Enqueueing public styles and scripts
 * - Shortcode output (Phase 3)
 * - Public-facing hooks and filters
 *
 * "Public" in WordPress terms means "not the admin area" — it's the
 * website that visitors see.
 *
 * Why separate public from admin?
 * - Performance: Public pages shouldn't load admin code
 * - Security: Public code has different permission requirements
 * - Organization: Clear separation of concerns
 *
 * @package    WP_Forever
 * @subpackage WP_Forever/public
 * @since      0.1.0
 */

// Prevent direct file access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and hooks for enqueueing
 * the public-facing stylesheet and JavaScript.
 *
 * @since 0.1.0
 */
class WP_Forever_Public {

	/**
	 * Enqueue public styles.
	 *
	 * This method is hooked to 'wp_enqueue_scripts' and loads CSS
	 * files needed on the front-end.
	 *
	 * Currently empty — uncomment when you have public-facing styles.
	 * In Phase 1, we don't have any front-end features yet.
	 *
	 * Tips for public styles:
	 * - Keep them minimal to avoid impacting page load
	 * - Consider loading conditionally (only on pages that need them)
	 * - Use unique class prefixes to avoid conflicts with themes
	 *
	 * @since 0.1.0
	 * @return void
	 */
	public function enqueue_styles(): void {
		// Uncomment when you have public-facing styles:
		// wp_enqueue_style(
		//     'wp-forever-public',                               // Handle.
		//     WP_FOREVER_PLUGIN_URL . 'assets/css/public.css',   // Source URL.
		//     array(),                                           // Dependencies.
		//     WP_FOREVER_VERSION                                 // Version.
		// );
	}

	/**
	 * Enqueue public scripts.
	 *
	 * This method is hooked to 'wp_enqueue_scripts' and loads JavaScript
	 * files needed on the front-end.
	 *
	 * Currently empty — uncomment when you have public-facing scripts.
	 * In Phase 1, we don't have any front-end features yet.
	 *
	 * Tips for public scripts:
	 * - Load in footer (last parameter = true) for better performance
	 * - Minimize dependencies on heavy libraries
	 * - Consider loading conditionally (only on pages that need them)
	 *
	 * @since 0.1.0
	 * @return void
	 */
	public function enqueue_scripts(): void {
		// Uncomment when you have public-facing scripts:
		// wp_enqueue_script(
		//     'wp-forever-public',                               // Handle.
		//     WP_FOREVER_PLUGIN_URL . 'assets/js/public.js',     // Source URL.
		//     array(),                                           // Dependencies.
		//     WP_FOREVER_VERSION,                                // Version.
		//     true                                               // Load in footer.
		// );
	}
}
